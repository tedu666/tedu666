/* eslint semi: "off", no-unused-vars: "off" */

var store = require('../..');

const token = store.get('token'); // or set ...
